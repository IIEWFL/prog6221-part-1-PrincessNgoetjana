﻿       

using System;
using System.Media;

// Play voice greeting
new SoundPlayer("greeting.wav").PlaySync();

// ASCII logo
Console.WriteLine(@"
   _____           _                _       
  / ____|         | |              (_)      
 | |     ___ _ __ | |__   ___  _ __ _  __ _ 
 | |    / _ \ '_ \| '_ \ / _ \| '__| |/ _` |
 | |___|  __/ | | | | | | (_) | |  | | (_| |
  \_____\___|_| |_|_| |_|\___/|_|  |_|\__,_|
        ");

// Ask for name
Console.Write("Enter your name: ");
string name = Console.ReadLine();
Console.WriteLine($"Hi {name}, I'm here to help you stay safe online!");

// Chat loop
while (true)
{
    Console.Write("\nAsk a question (or type 'exit'): ");
    string input = Console.ReadLine()?.ToLower();

    if (string.IsNullOrWhiteSpace(input))
    {
        Console.WriteLine("Please type something!");
        continue;
    }

    if (input.Contains("how are you"))
        Console.WriteLine("I'm always alert to protect you from cyber threats!");
    else if (input.Contains("purpose"))
        Console.WriteLine("To teach you about cybersecurity and staying safe online.");
    else if (input.Contains("password"))
        Console.WriteLine("Use strong, unique passwords. Add two-factor authentication!");
    else if (input.Contains("phishing"))
        Console.WriteLine("Be careful of fake emails and links. Don't click unknown stuff.");
    else if (input.Contains("safe browsing"))
        Console.WriteLine("Use secure websites (look for HTTPS) and don’t download suspicious files.");
    else if (input == "exit")
    {
        Console.WriteLine("Goodbye! Stay cyber safe!");
        break;
    }
    else
        Console.WriteLine("I didn't get that. Try asking about passwords, phishing, or safe browsing.");
}

